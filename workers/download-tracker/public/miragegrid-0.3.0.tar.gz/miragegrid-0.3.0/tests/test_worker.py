"""Worker source: live count, product homepage, isolated to miragegrid, no /event CTA."""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "workers" / "download-tracker" / "src"
JS = SRC / "index.js"
HOME = SRC / "homepage.js"
RUNTIME = SRC / "runtime.js"
BRIDGE = SRC / "bridge.js"
TOML = ROOT / "workers" / "download-tracker" / "wrangler.toml"
SIGIL = ROOT / "workers" / "download-tracker" / "public" / "sigil.png"


def _blob() -> str:
    return "\n".join(
        [
            JS.read_text(encoding="utf-8"),
            HOME.read_text(encoding="utf-8"),
            RUNTIME.read_text(encoding="utf-8"),
            BRIDGE.read_text(encoding="utf-8"),
        ]
    )


def test_worker_live_count_and_isolation() -> None:
    js = _blob()
    toml = TOML.read_text(encoding="utf-8")
    assert 'PROJECT = "miragegrid"' in js
    assert "await collectStats" in js or "collectStats(env)" in js
    assert "/count" in js
    assert "project" in js and "total" in js
    assert "not VibeLock" in js or "not the VibeLock" in js
    assert "isolated" in js.lower()
    assert 'href="/download?asset=' in js
    assert "live downloads" in js.lower() or "live download" in js.lower()
    homepage = HOME.read_text(encoding="utf-8")
    assert "POST /event" not in homepage
    assert "/event" not in homepage
    assert 'id = "f833961513eb44e3ba061e1d2031fe52"' in toml or 'id = "REPLACE_ME"' in toml
    assert 'name = "miragegrid-download-tracker"' in toml
    assert "ac575a9b822bea2bed97d0ab73aed238" in toml
    assert '"/count"' in toml
    assert "miragegrid-0.3.0.tar.gz" in js
    assert 'const VERSION = "0.3.0"' in js
    assert "miragegrid-0.2.0.tar.gz" not in js


def test_worker_product_homepage() -> None:
    home = HOME.read_text(encoding="utf-8")
    js = _blob()
    assert "MirageGrid — Aziel Eliab" in home
    assert "application/ld+json" in home
    assert '"@type": "SoftwareApplication"' in home or '"@type":"SoftwareApplication"' in home
    assert "citation_author" in home
    assert "How to cite" in home
    assert "cite.json" in home
    assert "id=\"workspace\"" in home
    assert "/v1/assign" in home
    assert "/v1/mesh" in home
    assert "/v1/route" in home
    assert "/v1/verify-receipt" in home
    assert 'class="brandrow"' in home
    assert 'class="brandmark"' in home
    assert 'src="/sigil.png"' in home
    assert 'alt=""' in home
    assert "everblooming sigil" not in home.lower()
    assert "everbloom" not in home.lower()
    assert "THE EVER BLOOMING FLOWER" not in home.upper()
    assert "/sigil.png" in home
    assert "Aziel Eliab" in home
    assert "Apache-2.0" in home
    assert "forks welcome" in home.lower()
    assert "not a VPN" in js
    assert "not an anonymity network" in js.lower()
    assert "zenodo.214" not in home.lower()
    assert "10.5281/zenodo" not in home
    assert SIGIL.is_file()
    assert SIGIL.read_bytes()[:8] == b"\x89PNG\r\n\x1a\n"
    assert 60_000 <= SIGIL.stat().st_size <= 90_000
    toml = TOML.read_text(encoding="utf-8")
    assert "/cite.json" in toml
    assert "/robots.txt" in toml
    assert "/sitemap.xml" in toml
    assert "/llms.txt" in toml
    assert "/ai.txt" in toml
    assert "/bridge.json" in toml
    assert "/design-packs" in toml
    assert "/shelves" in toml
    assert "/shelves" in js
    assert "design_of" in js
    assert "live-app" in js or "miragegrid.vibelock.workers.dev" in js
    assert "miragegrid-download-tracker.vibelock.workers.dev" in js
    assert "closed-by-creating-worker-miragegrid" in js or "live-app" in js
    assert "framagit_url: null" in js or "framagit: null" in js
    assert "/llms.txt" in js
    assert "/v1/bridge" in js
    assert "design-packs" in js
    assert "SEMANTIC-BRIDGE-1.0" in js
    assert "public_icann" in js
    assert "resolves_to_hub" in js
    assert "GPTBot" in js
    assert "Content-Signal" in js
    assert "15:20" not in home
    assert '"@id": "https://www.azieleliab.com/#aziel"' in home or "www.azieleliab.com/#aziel" in js

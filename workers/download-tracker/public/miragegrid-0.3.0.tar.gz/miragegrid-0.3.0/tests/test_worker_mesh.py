"""Suite mesh Live Nodes + QNM-BUILD-1.0 contract.

Default OFF. live|locked|isolated. No Node Gate. No auto-heal. Not anonymity.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MESH = (ROOT / "workers/download-tracker/src/mesh.js").read_text(encoding="utf-8")
RUNTIME = (ROOT / "workers/download-tracker/src/runtime.js").read_text(encoding="utf-8")
INDEX = (ROOT / "workers/download-tracker/src/index.js").read_text(encoding="utf-8")
HOMEPAGE = (ROOT / "workers/download-tracker/src/homepage.js").read_text(encoding="utf-8")
WRANGLER = (ROOT / "workers/download-tracker/wrangler.toml").read_text(encoding="utf-8")
README = (ROOT / "README.md").read_text(encoding="utf-8")
SKILL = (ROOT / "SKILL.md").read_text(encoding="utf-8")
WORKER_README = (ROOT / "workers/download-tracker/README.md").read_text(encoding="utf-8")


def test_mesh_contract_default_off_qnm_law() -> None:
    assert 'QNM_SPEC = "QNM-BUILD-1.0"' in MESH
    assert 'QNS_CD_SPEC = "QNS-CD-1.0"' in MESH
    assert "export const QNS_CD" in MESH
    assert "photon QNS1 packet transfer" in MESH
    assert "https://github.com/AzielEliab/qnm-node" in MESH
    assert "https://github.com/AzielEliab/aziel-runtime" in MESH
    assert "https://github.com/AzielEliab/azinterface" in MESH
    assert "softwares_tab: false" in MESH
    assert "qnsd_proxy: false" in MESH
    assert "public_proxy: false" in MESH
    assert "MESH_DEFAULT_OFF = true" in MESH
    assert "MESH_ANONYMITY_NETWORK = false" in MESH
    assert "MESH_NODE_GATE = false" in MESH
    assert "MESH_AUTO_HEAL = false" in MESH
    assert "MESH_IDENTITY = IDENTITY" in MESH or '"Aziel Eliab"' in MESH
    assert 'MESH_PRODUCT = "miragegrid"' in MESH
    assert 'MESH_PATH = "/v1/mesh"' in MESH
    assert "live|locked|isolated" in MESH
    assert "enabled_default: false" in MESH
    assert "anon_broadcast_publish_path: false" in MESH
    assert "Aziel Eliab" in MESH
    assert "code: extra.code || \"MESH-OK\"" in MESH or '"MESH-OK"' in MESH
    assert "QNS-CD-1.0" in MESH
    assert '"/v1/qnsd"' not in MESH
    assert "No public qnsd" in MESH or "no public qnsd" in MESH.lower()


def test_mesh_pointer_and_openapi_helpers() -> None:
    assert "export function meshPointer" in MESH
    assert "export function meshOpenApiPaths" in MESH
    assert "export function parseMeshDoc" in MESH
    assert "export function emptyMesh" in MESH
    assert "export function alignLiveNodes" in MESH
    assert "fraggate_slug: MESH_SLUG" in MESH
    assert "miragegrid_mesh_" in MESH


def test_mesh_proxies_via_aziel_runtime() -> None:
    assert "MESH_ROUTE_METHODS" in MESH
    assert "isMeshPath" in MESH
    assert "runMeshProxy" in MESH
    assert "handleMeshApi" in MESH
    assert "originFetch" in MESH
    assert '"/v1/mesh"' in MESH
    assert 'startsWith("/v1/mesh/")' in MESH
    assert "AZIEL_RUNTIME" in MESH
    assert "AZIEL_RUNTIME" in WRANGLER
    assert "aziel-runtime" in WRANGLER
    assert "/v1/mesh" in WRANGLER
    assert 'id = "f833961513eb44e3ba061e1d2031fe52"' in WRANGLER


def test_index_routes_mesh_before_runtime_catchall() -> None:
    assert 'from "./mesh.js"' in INDEX
    assert "handleMeshApi" in INDEX
    mesh_idx = INDEX.index("handleMeshApi(request, url, env)")
    runtime_idx = INDEX.index("handleRuntimeApi(request, url)")
    assert mesh_idx < runtime_idx
    not_found = INDEX.rindex('return json({ error: "not found" }, 404)')
    assert mesh_idx < not_found


def test_runtime_advertises_mesh_proxy_and_pointer() -> None:
    assert 'from "./mesh.js"' in RUNTIME
    assert "meshPointer" in RUNTIME
    assert "meshOpenApiPaths" in RUNTIME
    assert "...meshOpenApiPaths()" in RUNTIME
    assert "mesh: meshPointer()" in RUNTIME
    assert "/v1/mesh" in RUNTIME
    assert "QNM-BUILD-1.0" in RUNTIME
    assert "No Node Gate" in RUNTIME
    assert 'path === "/v1/mesh"' in RUNTIME or 'path.startsWith("/v1/mesh/")' in RUNTIME


def test_qns_cd_cross_map_on_live_nodes_payload() -> None:
    assert "export function qnsCdFields" in MESH
    assert "export function attachQnsCd" in MESH
    assert "...qnsCdFields()" in MESH
    assert "attachQnsCd(data)" in MESH
    assert "this_worker_is_node_gate: false" in MESH
    assert "fraggate_single_door: true" in MESH
    assert "MGS-NO-HOSTED-PLANT" in MESH
    assert "MGS-NO-HOSTED-APPLY" in MESH
    assert "channel_plane_is_vpn: false" in MESH
    assert "OUTLAST_HONESTY" in MESH
    assert "HASH_RECEIPT_CONTINUITY" in MESH
    assert "QNS-CD-1.0" in HOMEPAGE
    assert "QNS-CD-1.0" in RUNTIME
    assert "No public qnsd" in RUNTIME or "no public qnsd" in RUNTIME.lower()
    assert "Not a Softwares-tab product" in MESH


def test_home_live_nodes_strip_no_node_gate() -> None:
    assert 'id="meshStrip"' in HOMEPAGE
    assert 'id="meshLiveCount"' in HOMEPAGE
    assert 'id="meshLine"' in HOMEPAGE
    assert "Live Nodes" in HOMEPAGE
    assert "QNM-BUILD-1.0" in HOMEPAGE
    assert "No Node Gate" in HOMEPAGE
    assert "No auto-heal" in HOMEPAGE
    assert "Not an anonymity network" in HOMEPAGE
    assert "/v1/mesh" in HOMEPAGE
    assert 'product: "miragegrid"' in HOMEPAGE
    assert 'id="node-gate"' not in HOMEPAGE
    assert 'href="/node-gate"' not in HOMEPAGE
    assert "auto-heal this node" not in HOMEPAGE
    assert "miragegrid_mesh_node" in HOMEPAGE


def test_docs_advertise_mesh_proxy() -> None:
    assert "/v1/mesh" in README
    assert "/v1/mesh" in SKILL
    assert "QNM-BUILD-1.0" in WORKER_README
    assert "AZIEL_RUNTIME" in WORKER_README
    assert "Live Nodes" in WORKER_README
    assert "MESH-OK" in WORKER_README
    assert "enabled: false" in WORKER_README
    assert "Aziel Eliab" in MESH
    assert "QNS-CD-1.0" in README
    assert "QNS-CD-1.0" in SKILL
    assert "QNS-CD-1.0" in WORKER_README
    assert "photon QNS1" in README
    assert "photon QNS1" in SKILL
    assert "qnm-node" in README
    assert "aziel-runtime" in SKILL
    assert "no public qnsd" in WORKER_README.lower() or "No public qnsd" in WORKER_README


def test_split_wires_cold_copy_reheal_law() -> None:
    assert 'SPLIT_WIRES_LAW = "SPLIT THE WIRES"' in MESH
    assert 'SPLIT_WIRES_SPEC = "STW-1.0"' in MESH
    assert 'COLD_COPY_LAW = "COLD-COPY SURVIVAL"' in MESH
    assert 'COLD_COPY_SPEC = "CCS-1.0"' in MESH
    assert 'REHEAL_LAW = "REHEAL"' in MESH
    assert 'REHEAL_SPEC = "RH-1.0"' in MESH
    assert "ASSIGN_LIVE = true" in MESH
    assert "hostedStubRefuse" in MESH
    assert "refuseReheal" in MESH
    assert "tipPlaneContaminated" in MESH
    assert "socketsShare" in MESH
    assert "pull-only" in MESH
    assert "sender_fanout: false" in MESH
    assert "dwell_s: DWELL_S" in MESH or "dwell_s: 777" in MESH
    assert "clock_desync_is_yes: false" in MESH
    assert "quorum_is_truth: false" in MESH
    assert "unsend_unverified_body: false" in MESH
    assert "auto_splice: false" in MESH
    assert "shared: false" in MESH
    assert "live_body_sync: false" in MESH
    assert "server_pull_wipes_cold: false" in MESH
    assert "hash-absolute-refuse" in MESH
    assert "data_outlives_creators: true" in MESH
    assert "neighbor_talk_dirty_back_to_health: false" in MESH
    assert "vote-to-fix" in MESH
    assert "phoenix-wait" in MESH
    assert "own-tip+trusted-pull" in MESH
    assert "MESH-STUB" in MESH
    assert "RH-NO-NEIGHBOR-TALK" in MESH
    assert "RH-NO-VOTE-TO-FIX" in MESH
    assert "STW-TIP-BODY" in MESH
    assert "STW-SOCKET-SPLIT" in MESH
    assert '"vpn"' in MESH and '"hop"' in MESH and '"tunnel"' in MESH
    assert "assign stays live" in MESH
    assert "...meshLawFields()" in MESH
    assert "/v1/mesh/reheal" in MESH
    assert "MESH_AUTO_HEAL = false" in MESH
    assert "SPLIT THE WIRES" in README
    assert "COLD-COPY SURVIVAL" in README
    assert "REHEAL" in README
    assert "SPLIT THE WIRES" in SKILL
    assert "REHEAL" in SKILL
    assert "SPLIT THE WIRES" in HOMEPAGE
    assert "COLD-COPY SURVIVAL" in HOMEPAGE
    assert "REHEAL" in HOMEPAGE
    assert "Aziel Eliab" in MESH
    assert 'AZ_GENERATOR_SPEC = "AZ-GENERATOR-1.0"' in MESH
    assert 'GRID_SHIFT_SPEC = "MIRAGE-GRID-SHIFT-1.0"' in MESH
    assert "CLAIM_CLOCK_S = CLAIM_MINUTES * 60 + CLAIM_EXTRA_S" in MESH
    assert "CAP_7 = 7" in MESH
    assert "MIN_PAPERS = 49" in MESH
    assert 'FIRST_CLAIM_NAME = "www.survivalnetwork.az"' in MESH
    assert "az_generator: AZ_GENERATOR" in MESH
    assert "grid_shift: GRID_SHIFT" in MESH
    assert "public_stack: PUBLIC_STACK" in MESH
    assert "softwares_tab: false" in MESH
    assert "AZ-GENERATOR-1.0" in README
    assert "MIRAGE-GRID-SHIFT-1.0" in README
    assert "AZ-GENERATOR-1.0" in SKILL
    assert "MIRAGE-GRID-SHIFT-1.0" in HOMEPAGE
    assert "www.survivalnetwork.az" in MESH
    assert "15:20" not in HOMEPAGE
    assert "10.5281/zenodo" not in HOMEPAGE
    assert 'NO_FAN_SPEC = "NO-FAN-1.0"' in MESH
    assert "No falsification. No ambiguity. No misleading." in MESH
    assert "NO-FAN-FALSIFY" in MESH
    assert "NO-FAN-AMBIGUITY" in MESH
    assert "NO-FAN-MISLEAD" in MESH
    assert "refuseNoFan" in MESH
    assert "NO-FAN-1.0" in README
    assert "No falsification. No ambiguity. No misleading." in HOMEPAGE
    assert "NO-FAN-1.0" in SKILL
    assert 'AIRGAP_SPEC = "AIRGAP-1.0"' in MESH
    assert 'PAPER_VAULT_LAW = "PAPER-VAULT-ON-NODE"' in MESH
    assert "export const AIRGAP" in MESH
    assert "export const PAPER_VAULT" in MESH
    assert "airgap: AIRGAP" in MESH
    assert "paper_vault: PAPER_VAULT" in MESH
    assert "AZG-INCOMPLETE-VAULT" in MESH
    assert "STW-TIP-BODY" in MESH
    assert "vaultMultiply" in MESH
    assert "airgapMode" in MESH
    assert "refuseIncompleteVault" in MESH
    assert '"/v1/mesh/airgap"' in MESH
    assert '"/v1/mesh/vault"' in MESH
    assert "AIRGAP-1.0" in README
    assert "AIRGAP-1.0" in SKILL
    assert "AIRGAP-1.0" in HOMEPAGE
    assert "PAPER-VAULT-ON-NODE" in MESH
    assert "PAPER-VAULT-ON-NODE" in HOMEPAGE
    assert "no paper bytes on the 1s tip tick" in MESH
    assert "official hubs are not airgap Node Gate" in MESH
    assert "have-49-without-bytes" in MESH
    assert 'spec: "SEMANTIC-BRIDGE-1.0"' in MESH
    assert "semantic_bridge: SEMANTIC_BRIDGE" in MESH
    assert "resolves_to_hub: false" in MESH
    assert "CROSS-NETWORK-SURVIVAL-1.0" in MESH
    assert "Growth-ON" in MESH
    assert "15:20" not in HOMEPAGE
    assert "AZG-NOT-CALLABLE" in MESH
    assert "citeAzGenerator" in MESH
    assert "refuseCallGenerator" in MESH
    assert "lives: \"deep-node\"" in MESH
    assert "cap-7-mesh-authoritative" in MESH
    assert "public_icann: false" in MESH
    assert "public_host_pair: 2" in MESH
    assert '".aziel"' in MESH
    assert "MESH-GET-NO-ENABLE" in MESH
    assert MESH.count("let search =") == 1
    assert "AZG-NOT-CALLABLE" in SKILL
    assert "Cap-7 mesh DNS factory" in README
    assert "radio_phy: false" in MESH
    assert "AZG-NO-RADIO-PHY" in MESH
    assert "MESH-GET-NO-ENABLE" in MESH
